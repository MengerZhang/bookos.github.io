/*
 * file:		lib/system.c
 * auther:		Jason Hu
 * time:		2020/2/14
 * copyright:	(C) 2018-2020 by Book OS developers. All rights reserved.
 */

#include <lib/stdlib.h>

int system(const char *command)
{

    return 0;
}