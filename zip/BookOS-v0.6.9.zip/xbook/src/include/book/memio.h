/*
 * file:		include/book/memio.h
 * auther:		Jason Hu
 * time:		2020/1/31
 * copyright:	(C) 2018-2020 by Book OS developers. All rights reserved.
 */

#ifndef _BOOK_MEMIO_H
#define _BOOK_MEMIO_H

#include <lib/types.h>



#endif   /* _BOOK_MEMIO_H */
