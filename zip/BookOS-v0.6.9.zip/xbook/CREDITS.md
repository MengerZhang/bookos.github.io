# Owner  
This OS was creted by Book OS developers.  

Developer cards:  
```
Name: Jason Hu
City: China
E-mail: 2323168280@qq.com
```
```
Name: Yu Zhu
City: China
E-mail: 891085309@qq.com
```
```
Name: Suote127
City: China
E-mail: tswuyin_st127@qq.com
```
