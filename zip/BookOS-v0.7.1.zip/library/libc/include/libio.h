/*
 * file:		include/lib/libio.h
 * auther:		Jason Hu
 * time:		2020/2/14
 * copyright:	(C) 2018-2020 by Book OS developers. All rights reserved.
 */

#ifndef _LIB_LIBIO_H
#define _LIB_LIBIO_H

#include "_G_config.h"

#define _IO_BUFSIZ _G_BUFSIZ

#endif  /* _LIB_LIBIO_H */
