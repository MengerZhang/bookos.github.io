/*
 * file:		include/lib/_G_config.h
 * auther:		Jason Hu
 * time:		2020/2/14
 * copyright:	(C) 2018-2020 by Book OS developers. All rights reserved.
 */

#ifndef _LIB_G_CONFIG_H
#define _LIB_G_CONFIG_H

#define _G_BUFSIZ 8192

#endif  /* _LIB_G_CONFIG_H */
