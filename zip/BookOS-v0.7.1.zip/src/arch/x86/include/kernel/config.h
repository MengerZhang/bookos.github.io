/*
 * file:		arch/x86/include/kernel/config.h
 * auther:		Jason Hu
 * time:		2019/7/9
 * copyright:	(C) 2018-2020 by Book OS developers. All rights reserved.
 */

#ifndef _X86_CONFIG_H
#define _X86_CONFIG_H

//#define CONFIG_ZONE_DEBUG
//#define CONFIG_PAGE_DEBUG




#endif  /*_X86_CONFIG_H*/
