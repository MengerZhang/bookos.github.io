/*
 * file:		include/char/char.h
 * auther:		Jason Hu
 * time:		2019/10/25
 * copyright:	(C) 2018-2020 by Book OS developers. All rights reserved.
 */

#ifndef _DRIVER_CHAR_H
#define _DRIVER_CHAR_H

#include <lib/stddef.h>

PUBLIC void InitCharDevice();

#endif   /* _DRIVER_CHAR_H */
