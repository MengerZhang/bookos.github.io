
typedef unsigned int  uint;

struct SDL_Color{
uint r;
uint g;
uint b;
uint a; 
};
struct SDL_Renderer{
void *pixels;
SDL_Color color;
int w;
int h;
};

struct SDL_Window{
char *title;
int x;
int y;
int w;
int h;
int flag;

};

SDL_Window *SDL_CreateWindow(char *title, int x, int y,int  width,int  height, int flag);
SDL_Renderer* SDL_CreateRenderer(SDL_Window* window, int  index,int flags);
void SDL_SetRenderDrawColor(SDL_Renderer* renderer,uint r,uint g,uint b, uint a);
void SDL_RenderDrawPoint(SDL_Renderer* renderer,int x,int y);
void SDL_RenderPresent(SDL_renderer *renderer);