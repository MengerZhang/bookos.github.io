/*
 * file:		arch/x86/include/kernel/const.h
 * auther:		Jason Hu
 * time:		2019/6/23
 * copyright:	(C) 2018-2019 by Book OS developers. All rights reserved.
 */

#ifndef _X86_CONST_H
#define _X86_CONST_H



#endif  /*_X86_CONST_H*/
