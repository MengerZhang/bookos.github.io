/*
File:		include/sys/board.h
Contains:	header for board
Auther:		HZC
Time:		2019/2/16
Copyright:	(C) 2018-2019 by Retal developers. All rights reserved.
*/

#ifndef _GUI_BOARD_H_
#define _GUI_BOARD_H_


#endif

