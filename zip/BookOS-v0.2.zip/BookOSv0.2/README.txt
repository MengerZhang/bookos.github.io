﻿# BookOS
BookOS is a 32-bit operating system based on x86 platform. It has a simple multitasking, paging memory management, Fatxe file system, keyboard, mouse, video, clock driver, and a simple shell. Enjoy it!
E-mail：2323168280@qq.com
Update:
	-v0.2 2019/2/21
	-v0.1 2019/1/7
