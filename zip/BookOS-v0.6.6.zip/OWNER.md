# Owner  
This OS is owned by Book OS X developers.  
Developers:
Jason Hu
Yu Zhu
Suote127
...  
