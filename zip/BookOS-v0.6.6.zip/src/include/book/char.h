/*
 * file:		include/book/char.h
 * auther:		Jason Hu
 * time:		2019/10/25
 * copyright:	(C) 2018-2019 by Book OS developers. All rights reserved.
 */

#ifndef _BOOK_CHAR_H
#define _BOOK_CHAR_H

#include <share/stddef.h>

PUBLIC void InitCharDevice();

#endif   /* _BOOK_CHAR_H */
