#ifndef _GUI_H
#define _GUI_H

#include <sys/config.h>

#ifdef _CONFIG_GUI_BASIC_
	
	#include <gui/basic/basic.h>
	#include <gui/basic/graphic.h>
	#include <gui/basic/bmp.h>
	#include <gui/basic/font.h>
	#include <gui/basic/image.h>
	#include <gui/basic/jpeg.h>

#endif

#ifdef _CONFIG_GUI_BOGUI_
	
	#include <gui/bogui/bogui.h>
	
#endif

#include <gui/color.h>

struct gui
{
	void (*pixel_write)(int x, int y);
	uint32 (*pixel_read)(int x, int y);
	
};

extern struct gui gui;

void init_gui();
void gui_environment_init();
void gui_interface_init();

#endif //_GUI_H