#ifndef _GUI_BOGUI_H
#define _GUI_BOGUI_H

#include <sys/config.h>

#ifdef _CONFIG_GUI_BOGUI_

void init_bogui();

void bogui_draw_point(int32 x, int32 y, uint32 color);
void bogui_draw_rect(int32 x, int32 y, uint32 width, uint32 height, uint32 color);
void bogui_draw_line(int32 x0, int32 y0, int32 x1, int32 y1, uint32 color);
void bogui_draw_buffer(int32 x, int32 y, uint32 width, uint32 height, uint32 *buffer);

#endif //_CONFIG_GUI_BOGUI_

#endif //_GUI_BOGUI2_H