#ifndef _GUI_BASIC_JPEG_H
#define _GUI_BASIC_JPEG_H

#include <types.h>

/* jpeg.c */
/*
#define JPEG_MAX_WIDTH 1024
#define JPEG_MAX_HEIGHT 768

struct DLL_STRPICENV { int *work; };

struct jpeg_RGB {
	unsigned char b, g, r, t;
};
typedef unsigned char UCHAR;

int info_JPEG(struct DLL_STRPICENV *env, int *info, int size, UCHAR *fp);
int decode0_JPEG(struct DLL_STRPICENV *env, int size, UCHAR *fp, int b_type, UCHAR *buf, int skip);
*/
#endif //_GUI_BASIC_JPEG_H