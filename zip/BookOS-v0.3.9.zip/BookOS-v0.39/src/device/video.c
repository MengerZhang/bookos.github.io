/*
File:		device/video.c
Contains:	driver for video
Auther:		Hu Zicheng
Time:		2019/1/29
Copyright:	(C) 2018-2019 by BookOS developers. All rights reserved.
E-mail:		2323168280@qq.com
*/

#include <sys/config.h>

#ifdef _CONFIG_DEVIVE_VIDEO_

#include <sys/dev.h>
#include <sys/core.h>

#include <string.h>
#include <sys/mm.h>
#include <sys/gui.h>

struct video_info video_info;

void init_video()
{
	//uint32_t *vram_addr;
	//直接从地址获取
	video_info.bits_per_pixe = *((uint16_t *)VIDEO_INFO_ADDR);
	video_info.width = (uint32_t )(*((uint16_t *)(VIDEO_INFO_ADDR+2)));
	video_info.height = (uint32_t )(*((uint16_t *)(VIDEO_INFO_ADDR+4)));
	
	video_info.pixel_width = video_info.bits_per_pixe/8;
	
	//先获取地址，在转换成指针
	//vram_addr = (uint32_t *)(VIDEO_INFO_ADDR+6);
	video_info.vram = (uint8_t *) VIDEO_VRAM_ADDR;
	
	display_start_logo();
	
}

void video_transmit(struct video_message_s *msg)
{
	//msg error, return
	if (msg == NULL) {	
		return;
	}

	//get vram start addr
	uint8 *vram;

	//we do different operate by message type
	if (msg->m_type == VIDEO_MSG_WRITE_PIXEL) {
		
		//if out of screen
		if (msg->m_x < 0 || msg->m_y < 0 || msg->m_x >= video_info.width || \
			msg->m_y >= video_info.height) {
			return;
		}

		vram = (uint8 *)(video_info.vram + \
		((msg->m_y*video_info.width+msg->m_x))*video_info.pixel_width);

		//we write vram through different model
		#ifdef _VIDEO_16_MODE_
			*vram++ = msg->m_color&0xff;
			*vram = (msg->m_color>>8)&0xff;
		#endif //_VIDEO_16_MODEL_

		#ifdef _VIDEO_24_MODE_
			*vram++ = msg->m_color&0xff;
			*vram++ = (msg->m_color>>8)&0xff;
			*vram = (msg->m_color>>16)&0xff;
		#endif //_VIDEO_24_MODEL_

	} else if (msg->m_type == VIDEO_MSG_READ_PIXEL) {
		//if out of screen
		if (msg->m_x < 0 || msg->m_y < 0 || msg->m_x >= video_info.width || \
			msg->m_y >= video_info.height) {
			return;
		}

		vram = (uint8 *)(video_info.vram + \
		((msg->m_y*video_info.width+msg->m_x))*video_info.pixel_width);
		
		//we write vram through different model
		#ifdef _VIDEO_16_MODE_
			msg->m_color = vram[0] | (vram[1]<<8);
		#endif //_VIDEO_16_MODEL_

		#ifdef _VIDEO_24_MODE_
			msg->m_color = vram[0] | (vram[1]<<8) | (vram[2]<<16);
		#endif //_VIDEO_24_MODEL_
	}
}

void video_clean_screen()
{
	int x, y;
	for(y = 0; y < video_info.height; y++){	//high*2才能写完全部，不然只有一半
		for(x = 0; x < video_info.width; x++){
			//vram_write_pixel(x, y, COLOR_BLACK);
		}
	}
}

void sys_get_screen(int *width, int *height)
{
	*width = video_info.width;
	*height = video_info.height;
}

#endif //_CONFIG_DEVIVE_VIDEO_
