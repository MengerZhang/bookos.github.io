/*
File:		gui/bogui/bogui.c
Contains:	gui module
Auther:		Hu Zicheng
Time:		2019/4/7
Copyright:	(C) 2018-2019 by BookOS developers. All rights reserved.
E-mail:		2323168280@qq.com
*/

#include <sys/core.h>

#include <sys/dev.h>
#include <sys/gui.h>

#include <string.h>

struct gui gui;

void init_gui()
{
	gui_environment_init();
	gui_interface_init();
	
}

void gui_environment_init()
{
	#ifdef _CONFIG_GUI_BASIC_
		init_gui_basic();
	#endif
	#ifdef _CONFIG_GUI_BOGUI_
		init_bogui();
	#endif
}


void gui_interface_init()
{
	#ifdef _CONFIG_GUI_BOGUI_
		/*
		gui.pixel_read = ;
		gui.pixel_write = ;
		*/
	#endif
	
}
