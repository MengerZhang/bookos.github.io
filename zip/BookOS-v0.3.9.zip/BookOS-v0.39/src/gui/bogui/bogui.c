/*
File:		gui/bogui/bogui.c
Contains:	bogui init
Auther:		Hu Zicheng
Time:		2019/4/21
Copyright:	(C) 2018-2019 by BookOS developers. All rights reserved.
E-mail:		2323168280@qq.com
*/

#include <sys/config.h>

#ifdef _CONFIG_GUI_BOGUI_

#include <sys/gui.h>
#include <gui/color.h>
#include <sys/dev.h>
#include <string.h>

void init_bogui()
{
	/*bogui_draw_point(50, 25, COLOR_RGB(230,230,230));
    bogui_draw_line(10, 100, 150, 250, COLOR_RGB(0,0,230));*/
/*
    uint16 *wbuf = mm.malloc(800*600*4);

    memset16(wbuf, COLOR_RGB(230,230,230), 800*600*2);
    bogui_draw_buffer(0, 0, 800, 600, (uint32 *)wbuf);
    bogui_draw_rect(300, 200, 320, 240, *((uint32 *)wbuf));
*/  
}
/*draw a point on the screen*/
void bogui_draw_point(int32 x, int32 y, uint32 color)
{
	struct video_message_s msg;
    msg.m_type = VIDEO_MSG_WRITE_PIXEL;
    msg.m_x = x;
    msg.m_y = y;
    msg.m_color = color;
    video_transmit(&msg);
}

void bogui_draw_rect(int32 x, int32 y, uint32 width, uint32 height, uint32 color)
{
	struct video_message_s msg;

    msg.m_type = VIDEO_MSG_WRITE_PIXEL;
    msg.m_color = color;

    int x0, y0;
    for (y0 = y; y0 < y + height; y0++) {
        for (x0 = x; x0 < x + width; x0++) {
            msg.m_x = x0;
            msg.m_y = y0;
            video_transmit(&msg);            
        }
    }
}

void bogui_draw_line(int32 x0, int32 y0, int32 x1, int32 y1, uint32 color)
{
	int i, x, y, len, dx, dy;
	dx = x1 - x0;
	dy = y1 - y0;
	
	x = x0 << 10;
	y = y0 << 10;
	
	if(dx < 0){
		dx = -dx;
	}
	if(dy < 0){
		dy = -dy;
	}
	if(dx >= dy ){
		len = dx + 1;
		if(x0 > x1){
			dx = -1024;
		} else {
			dx = 1024;
			
		}
		if(y0 <= y1){
			dy = ((y1 - y0 + 1) << 10)/len;
		} else {
			dy = ((y1 - y0 - 1) << 10)/len;
		}
		
		
	}else{
		len = dy + 1;
		if(y0 > y1){
			dy = -1024;
		} else {
			dy = 1024;
			
		}
		if(x0 <= x1){
			dx = ((x1 - x0 + 1) << 10)/len;
		} else {
			dx = ((x1 - x0 - 1) << 10)/len;
		}	
	}

    struct video_message_s msg;

    msg.m_type = VIDEO_MSG_WRITE_PIXEL;
    msg.m_color = color;

	for(i = 0; i < len; i++){
		//buf[((y >> 10)*wide + (x >> 10))*3] = color;
		//graph_write_pixel(buffer,(x >> 10), (y >> 10), color);
		msg.m_x = x>>10;
        msg.m_y = y>>10;
        video_transmit(&msg);

		x += dx;
		y += dy;
	}
}

void bogui_draw_buffer(int32 x, int32 y, uint32 width, uint32 height, uint32 *buffer)
{
	struct video_message_s msg;

    msg.m_type = VIDEO_MSG_WRITE_PIXEL;
    int x0, y0, bx, by;
    for (y0 = y, by = 0; y0 < y + height && by < height; y0++, by++) {
        for (x0 = x, bx = 0; x0 < x + width && bx < width; x0++, bx++) {
            msg.m_x = x0;
            msg.m_y = y0;

            msg.m_color = *(uint32 *)(buffer + (by*width+bx));
            video_transmit(&msg);            
        }   
    }
}

#endif //_CONFIG_GUI_BOGUI_
