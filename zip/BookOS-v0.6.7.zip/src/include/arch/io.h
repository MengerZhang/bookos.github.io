/*
 * file:		include/arch/io.h
 * auther:		Jason Hu
 * time:		2020/1/31
 * copyright:	(C) 2018-2019 by Book OS developers. All rights reserved.
 */

#ifndef _ARCH_IO_H
#define _ARCH_IO_H

#include <book/arch.h>


#endif   /* _ARCH_IO_H */
