/*
 * file:		include/book/blk-buffer.h
 * auther:		Jason Hu
 * time:		2020/1/31
 * copyright:	(C) 2018-2019 by Book OS developers. All rights reserved.
 */

#ifndef _MM_MEMIO_H
#define _MM_MEMIO_H

#include <share/types.h>



#endif   /* _MM_MEMIO_H */
