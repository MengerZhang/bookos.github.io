#include "lib/stdio.h"
#include "lib/stdlib.h"
#include "lib/file.h"
#include "lib/conio.h"
#include "lib/conio.h"

int main(int argc, char *argv[])
{
	get_console();
	printf("hello\n");
	
	int key;
	while(1){
		key = getch();
		if(key != EOF){
			if(key > FLAG_EXT){
				
			}else{
				putch(key);
			}
			if(key == 'q'){
				break;
			}
			key = EOF;
		}
		
	}
	close_console();
	return 0;
}

