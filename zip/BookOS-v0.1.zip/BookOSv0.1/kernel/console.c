#include "kernel/console.h"
#include "driver/vga.h"
#include "lib/stdarg.h"

struct console *current_console;

struct console console_table[MAX_CONSOLE_NR];

void init_console()
{
	struct console *cons;
	int i;
	for(i = 0; i < MAX_CONSOLE_NR; i++){
		cons = &console_table[i];
		console_init(cons, i);
	}
	
	select_console(0);
	current_console->status = CONSOLE_ACTIVE;
}

void console_init(struct console *cons, int id)
{
	
	int vram_size = V_MEM_SIZE>>1;	//in word
	int con_vram_size = vram_size/MAX_CONSOLE_NR;
	
	cons->id = id;
	cons->status = CONSOLE_IDLE;
	
	cons->vram_addr = con_vram_size*id;
	cons->vram_limit = con_vram_size;
	cons->current_start_addr = cons->vram_addr;
	
	cons->cursor = cons->vram_addr;

	cons->keybord_data = EOF;
	cons->task = NULL;
	
	if(current_console == console_table){
		cons->cursor = VGA.cursor_pos;
	}else{
		
	}
	set_cursor(cons->cursor);
}

void console_get()
{
	struct task *task = task_current();
	
	current_console->status = CONSOLE_IDLE;
	select_console(CONSOLE_TEXT);
	current_console->status = CONSOLE_ACTIVE;
	current_console->task = task;	//绑定任务
}

void console_close()
{
	current_console->status = CONSOLE_IDLE;
	current_console->task = NULL;	//取消任务绑定
	//把屏幕清空
	console_clean();
	
	select_console(CONSOLE_SHELL);
	current_console->status = CONSOLE_ACTIVE;
}

void out_char(struct console *cons, char ch)
{
	uint8_t *vram = (uint8_t *)(V_MEM_BASE + cons->cursor *2) ;
	switch(ch){
		case '\n':
			if(cons->cursor < cons->vram_addr + cons->vram_limit - SCREEN_WIDTH){
				cons->cursor = cons->vram_addr + SCREEN_WIDTH*((cons->cursor - cons->vram_addr)/SCREEN_WIDTH+1);
			}
			break;
		case '\b':
			if(cons->cursor > cons->vram_addr){
				cons->cursor--;
				*(vram-2) = ' ';
				*(vram-1) = COLOR_DEFAULT;
			}
			break;
		default: 
			if(cons->cursor < cons->vram_addr + cons->vram_limit - 1){
				*vram++ = ch;
				*vram++ = COLOR_DEFAULT;
				cons->cursor++;
			}
			break;
	}
	while(cons->cursor >= cons->current_start_addr + SCREEN_SIZE){
		scroll_screen(cons, SCREEN_DOWN);
	}
	flush(cons);
}

void flush(struct console *cons)
{
	set_cursor(cons->cursor);
	set_video_start_addr(cons->current_start_addr);
}

void select_console(int id)
{
	
	if(id< 0 || id >= MAX_CONSOLE_NR){
		return;
	}
	
	current_console = &console_table[id];
	flush(current_console);
	
}

void scroll_screen(struct console *cons, int direction)
{
	if(direction == SCREEN_UP){
		if(cons->current_start_addr > cons->vram_addr){
			cons->current_start_addr -= SCREEN_WIDTH;
		}
	}else if(direction == SCREEN_DOWN){
		if(cons->current_start_addr + SCREEN_SIZE < cons->vram_addr + cons->vram_limit){
			cons->current_start_addr += SCREEN_WIDTH;
		}
	}else{
		
	}
	
	flush(cons);
}

void console_clean()
{
	current_console->cursor = current_console->vram_addr;
	current_console->current_start_addr = current_console->vram_addr;
	flush(current_console);
	uint8_t *vram = (uint8_t *)(V_MEM_BASE + current_console->cursor *2) ;
	int i;
	for(i = 0; i < current_console->vram_limit*2; i+=2){
		*vram = 0;
		vram += 2;
	}
}


void console_putchar(uint8_t ch)
{
	lock_acquire(VGA.lock);
	out_char(current_console, ch);
	lock_release(VGA.lock);
}


int console_print(const char *fmt, ...)
{
	lock_acquire(VGA.lock);
	
	int i;
	char buf[256];
	va_list arg = (va_list)((char*)(&fmt) + 4); /*4是参数fmt所占堆栈中的大小*/
	i = vsprintf(buf, fmt, arg);
	print_buf(buf, i);
	
	lock_release(VGA.lock);
	
	return i;
}


