#ifndef _LIB_CONST_H
#define _LIB_CONST_H
#include "lib/stdint.h"

#define OS_NAME "Book OS"
#define OS_VERSION "0.01"
#define OS_COPYRIGHT "Book OS Developers"
#define OS_AUTHER "Eric hu"

#endif

