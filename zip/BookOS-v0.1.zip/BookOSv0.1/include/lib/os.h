#ifndef _LIB_OS_H
#define _LIB_OS_H
#include "lib/stdint.h"

#define BOOT_KBD 1
#define BOOT_BIOS 2
#define BOOT_CF9 3
#define BOOT_TRIPLE 4


void reboot(int reboot_type);

#endif

