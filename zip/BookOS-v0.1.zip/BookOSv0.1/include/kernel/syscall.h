#ifndef _SYSCALL_H
#define _SYSCALL_H
#include "kernel/types.h"
#include "kernel/task.h"

#define _NR_PUTMAILBOX 1
#define _NR_GETMAILBOX 2

#define _NR_MALLOC 3
#define _NR_FREE 4

#define _NR_EXIT 10
#define _NR_WAIT 11
#define _NR_GETPID 12
#define _NR_PS 13

#define _NR_GETCH 20
#define _NR_PUTCH 21
#define _NR_PRINTF 22
#define _NR_CLEAR 23

#define _NR_GETICKS 30
#define _NR_GET_CONSOLE   31
#define _NR_CLOSE_CONSOLE 32

#define _NR_GETTIME 33

#define _NR_REBOOT 34

#define NR_SYS_CALL 40

extern sys_call_t sys_call_table[NR_SYS_CALL];

void init_syscall();//初始化中断调用

/*interrupt.asm*/
void intrrupt_sys_call();//中断调用服务程序

#endif

