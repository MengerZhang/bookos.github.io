#ifndef _DRIVER_CONSOLE_H_
#define _DRIVER_CONSOLE_H_
#include "kernel/types.h"
#include "kernel/ioqueue.h"
#include "kernel/task.h"
#include "kernel/lock.h"

#define MAX_CONSOLE_NR 2

#define SCREEN_UP -1
#define SCREEN_DOWN 1

#define SCREEN_WIDTH 80
#define SCREEN_HEIGHT 25

#define CONSOLE_IDLE 0
#define CONSOLE_ACTIVE 1

#define CONSOLE_SHELL 0			//console for shell
#define CONSOLE_TEXT 1			//console for text

#define SCREEN_SIZE (SCREEN_WIDTH * SCREEN_HEIGHT)

struct console
{
	int id;
	int status;
	uint32_t current_start_addr;
	uint32_t vram_addr;
	uint32_t vram_limit;
	uint32_t cursor;
	int keybord_data;
	struct task *task;
};

extern struct console console_table[MAX_CONSOLE_NR];
extern struct console *current_console;

void init_console();
void console_init(struct console *cons, int id);
void out_char(struct console *cons, char ch);
void select_console(int id);
void scroll_screen(struct console *cons, int direction);
void flush(struct console *cons);

void console_get();
void console_close();

void console_clean();
void console_putchar(uint8_t ch);
int console_print(const char *fmt, ...);

#endif //_DRIVER_CONSOLE_H_

