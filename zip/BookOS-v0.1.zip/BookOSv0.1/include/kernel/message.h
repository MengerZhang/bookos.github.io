#ifndef _MESSAGE_H
#define _MESSAGE_H
#include "kernel/types.h"


#endif

