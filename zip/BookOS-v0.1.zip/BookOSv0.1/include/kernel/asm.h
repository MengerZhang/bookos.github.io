#ifndef _ASM_H
#define _ASM_H
#include "kernel/types.h"

void asm_nop();

#endif

