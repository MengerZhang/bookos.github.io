#ifndef _INTERRUPTION_H
#define _INTERRUPTION_H
#include"kernel/types.h"
#include"kernel/ioqueue.h"

#endif