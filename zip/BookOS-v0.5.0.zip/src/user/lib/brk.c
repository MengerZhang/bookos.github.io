/*
 * file:		user/lib/brk.c
 * auther:	    Jason Hu
 * time:		2019/8/10
 * copyright:	(C) 2018-2019 by Book OS developers. All rights reserved.
 */

#include <user/unistd.h>
#include <share/stdint.h>
#include <share/types.h>
#include <user/conio.h>

/**
 * _brk - 设置断点值
 * @addr: 设置的地址
 * 
 * 如果addr为0，就返回当前断点值
 */
extern unsigned int _brk(void * addr);

/* This must be initialized data because commons can't have aliases.  */
static void *__curbrk = 0;

/**
 * brk - 设置断点值
 * @addr: 设置的地址
 * 
 * 成功返回0，失败返回-1
 */
int __brk(void *addr)
{
  	void *newbrk;

	/* 保存新的brk值 */
	__curbrk = newbrk = (void *) _brk(addr);
	
	// printf("__brk: %x\n", __curbrk);
	/* 检测执行后的结果 */
	if (newbrk < addr) {
      	return -1;
    }

 	return 0;
}

/**
 * __sbrk - 让断点移动位置
 * @increment: 移动的距离，可正可负
 * 
 * 返回移动前的brk指针位置
 * 成功则返回brk地址，失败则返回-1指针，而不是NULL
 */
void *__sbrk(int increment)
{
  	void *oldbrk;
  	/* If this is not part of the dynamic library or the library is used
	via dynamic loading in a statically linked program update
	__curbrk from the kernel's brk value.  That way two separate
	instances of __brk and __sbrk can share the heap, returning
	interleaved pieces of it.  */
  	
	/* If have not Initialized */
	if (__curbrk == NULL)
    	if (__brk (0) < 0)      /* Initialize the break.  */
      		return (void *) -1;
	
	/* If no increment, return current brk. */
  	if (increment == 0)
    	return __curbrk;

	/* Get brk */
  	oldbrk = __curbrk;

	/* If brk not right or __brk failed, return -1. */
  	if ((increment > 0 ?
    	((uint32_t) oldbrk + (uint32_t) increment < (uint32_t) oldbrk) :
       	((int32_t)oldbrk < -((int32_t)increment))) ||
      	__brk ((void *)((int32_t)oldbrk + (int32_t)increment)) < 0)
    	return (void *) -1;
	
	// printf("__sbrk: %x\n", oldbrk);
	
	return oldbrk;
}