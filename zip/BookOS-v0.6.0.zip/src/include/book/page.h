/*
 * file:		include/book/page.h
 * auther:		Jason Hu
 * time:		2019/7/1
 * copyright:	(C) 2018-2019 by Book OS developers. All rights reserved.
 */

#ifndef _BOOK_PAGE_H
#define _BOOK_PAGE_H

#include <share/stddef.h>

#endif   /*_BOOK_PAGE_H */
