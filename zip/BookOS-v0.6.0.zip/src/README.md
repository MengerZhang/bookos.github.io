# 目录内容介绍 
arch-平台相关的内容  
include-内核的头文件  
init-内核初始化  
kernel-内核核心文件  
share-共享文件，内核和用户都可以使用的  
usr-用户文件  
hal-硬件抽象文件
driver-驱动程序文件
