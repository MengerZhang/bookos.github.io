# Book-OS-X*(XBook) Finished task.  

* new file system（BOFS v0.3）
--2019.12.1--
* synclock
* mutexlock
* spinlock
--2019.11.17--
* flat file system of device file
* new keyboard driver
* char device
* ide driver
* ramdisk driver
* block device
* new HAL define
* memory cache
* node phy memory management
--2019.10.21--
* keyboard driver
* keyboard hal
* work queue
* task assist
* softirq
--2019.8.22--
* realloc and calloc
* malloc and free
* brk and sbrk
--2019.8.11--
* fork and execv
* sync lock
* semaphore and semaphore2
* atomic operate
* load ELF binary
* exit and wait
* sleep and wakeup
* block and unblock
* user process
* kernel thread
* VMSpace memory
--2019.8.10--
* Slab memory
* Vmarea memory
--2019.7.26--
* buddy memory  
--2019.7.4--  
* ram hal  
--2019.7.3--  
* cpu hal  
--2019.6.27--  
* load kernel with elf format  
* 32 bits protect mode  
* multi-platform architecture
* get memory size by ards  
* page mode  
* gate and segment descriptor  
* HAL (Hardware Abstraction Layer)  
* list struct  
* bitmap struct  
* debug system  
* display hal  
* clock hal  
* console driver  
* clock driver  
* string lib  
--2019.6.26--  
