#ifndef _GUI_IMAGE_H_
#define _GUI_IMAGE_H_

#include <stdint.h>
void display_start_logo();

#endif

