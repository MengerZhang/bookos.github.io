#ifndef _CONFIG_H_
#define _CONFIG_H_

#define _DEVICE_VIDEO_ 
	#define _VIDEO_16
	/*#define _VIDEO_24*/

#endif
