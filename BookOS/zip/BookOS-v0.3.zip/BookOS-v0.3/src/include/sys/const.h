#ifndef _CONST_H_
#define _CONST_H_

/*
Version: -v0.1 2018/9/26~2019/1/7
Version: -v0.2 2019/1/8~2019/2/21
Version: -v0.3 2019/2/22~2019/4/6

*/


#define OS_NAME "Book OS"
#define OS_VERSION "0.3"
#define OS_COPYRIGHT "(C) 2018-2019 by Book OS developers. All rights reserved."
#define OS_AUTHER "Hu Zicheng"

#endif

