a.img	是软件镜像，操作系统在上面
c.img	在bochs和qemu虚拟机中的第一个磁盘（主通道，一磁盘）
c.img	在bochs和qemu虚拟机中的第二个磁盘（主通道，二磁盘）
hd.vhd	在Oracle VM virtualBox虚拟机中的第一个磁盘（主通道，一磁盘）
hd01.vhd	在Oracle VM virtualBox虚拟机中的第二个磁盘（主通道，二磁盘）

由于某些原因，不提供VmWare虚拟机磁盘。